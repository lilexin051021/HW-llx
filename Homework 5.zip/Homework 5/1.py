import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

#Load data
def load_movielens_data():
    user_columns = ['user_id', 'age', 'gender', 'occupation', 'zip_code']
    item_columns = ['movie_id', 'title', 'release_date', 'video_release_date', 'IMDb_URL', 
                    'unknown', 'Action', 'Adventure', 'Animation', 'Children', 'Comedy', 
                    'Crime', 'Documentary', 'Drama', 'Fantasy', 'Film-Noir', 'Horror', 
                    'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western']
    rating_columns = ['user_id', 'movie_id', 'rating', 'timestamp']
    try:
        users = pd.read_csv('ml-100k/u.user', sep='|', names=user_columns)
        items = pd.read_csv('ml-100k/u.item', sep='|', names=item_columns, encoding='latin-1')
        ratings = pd.read_csv('ml-100k/u.data', sep='\t', names=rating_columns)
        return users, items, ratings
    except FileNotFoundError:
        print("Please ensure that the ml-100k dataset file is in the correct path")
        return None, None, None

# Constructing a utility matrix
def create_utility_matrix(ratings):
    utility_matrix = ratings.pivot(index='user_id', columns='movie_id', values='rating')
    return utility_matrix

# Calculate user similarity
def calculate_similarity(utility_matrix):
    user_means = utility_matrix.mean(axis=1)
    centered_matrix = utility_matrix.sub(user_means, axis=0)
    centered_matrix_filled = centered_matrix.fillna(0)
    similarity_matrix = cosine_similarity(centered_matrix_filled)
    similarity_df = pd.DataFrame(similarity_matrix, 
                                 index=utility_matrix.index, 
                                 columns=utility_matrix.index)
    return similarity_df, centered_matrix, user_means

#Get the most similar users
def get_similar_users(user_id, similarity_df, n=10):
    similar_users = similarity_df[user_id].sort_values(ascending=False)
    similar_users = similar_users[similar_users.index != user_id]
    return similar_users.head(n)

#Prediction score
def predict_rating(user_id, item_id, utility_matrix, similarity_df, user_means, k=10):
    target_user_mean = user_means[user_id]
    similar_users = get_similar_users(user_id, similarity_df, k)
    item_ratings = utility_matrix.loc[similar_users.index, item_id]
    valid_ratings = item_ratings.dropna()
    if valid_ratings.empty:
        return target_user_mean     
    valid_similarities = similar_users.loc[valid_ratings.index]
    numerator = (valid_ratings - user_means.loc[valid_ratings.index]).dot(valid_similarities)
    denominator = valid_similarities.sum()  
    if denominator == 0:
        return target_user_mean
    predicted_rating = target_user_mean + (numerator / denominator)
    return predicted_rating

def main():
    users, items, ratings = load_movielens_data()
    if users is None:
        return
    
    utility_matrix = create_utility_matrix(ratings)
    
    similarity_df, centered_matrix, user_means = calculate_similarity(utility_matrix)
    
    target_user_id = 1
    target_item_id = 508
    
    similar_users = get_similar_users(target_user_id, similarity_df, 10)
    print(f"The 10 most similar users of user {target_user_id}:")
    print(similar_users)
    
    print("\nSimilar user ratings for item 508:")
    for user_id in similar_users.index:
        rating = utility_matrix.loc[user_id, target_item_id]
        print(f"User {user_id}: Rating={rating}" if not np.isnan(rating) else f"User {user_id}: Not rated")
    
    predicted_rating = predict_rating(target_user_id, target_item_id, 
                                     utility_matrix, similarity_df, user_means)
    print(f"\n User {target_user_id}’s expected rating for item {target_item_id}: {predicted_rating:.2f}")

if __name__ == "__main__":
    main()
